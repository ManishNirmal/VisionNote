declare module '@editorjs/link';
declare module '@editorjs/header';
declare module '@editorjs/list';
declare module '@editorjs/inline-code';
declare module '@editorjs/image';
declare module 'editorjs-parser';
